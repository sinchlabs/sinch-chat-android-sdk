package com.example.sinchchatexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.messaging.FirebaseMessaging
import com.sinch.chat.sdk.*
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
//            if (task.isSuccessful) {
//                initializeSinchChatSDK(task.result)
//            } else {
                initializeSinchChatSDK(null)
//            }
                setIdentity()
//        }

    }

    private fun initializeSinchChatSDK(deviceToken: String?) {
        val options = SinchInitializationOptions(deviceToken)
        SinchChatSDK.initialize(applicationContext, options)
    }

    private fun setIdentity() {
        // two types of identity
        // anonymouse
//        val anonymousIdentity = SinchIdentity.Anonymous
        // self signed
        val secret = "{{ secret }}"
        val clientID = "{{client_id}}"
        val projectID = "{{project_id}}"
        val configID = "{{config_id}}"

        val internalUserID = "example@domain.com"
        val signedUserID = HmacSha512.generate(internalUserID, secret)
        val signedIdentity = SinchIdentity.SelfSigned(internalUserID, signedUserID)

        val config = SinchConfig(clientID, projectID, configID, SinchRegion.EU1, "")


        SinchChatSDK.setIdentity(config, signedIdentity) { result ->
            if (result.isSuccess) {
                showChat()
            }
        }

    }

    private fun showChat() {
        SinchChatSDK.chat.start(this)
    }
}

object HmacSha512 {

    fun generate(message: String, key: String): String {
        val mac: Mac = Mac.getInstance("HmacSHA512")
        mac.init(SecretKeySpec(key.encodeToByteArray(), mac.algorithm))
        return mac.doFinal(message.encodeToByteArray()).joinToString(separator = "") { "%02x".format(it) }
    }
}
