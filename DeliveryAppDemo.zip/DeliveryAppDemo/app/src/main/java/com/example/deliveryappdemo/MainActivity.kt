package com.example.deliveryappdemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.deliveryappdemo.ui.theme.DeliveryAppDemoTheme
import com.sinch.chat.sdk.SinchChatSDK
import com.sinch.chat.sdk.SinchConfig
import com.sinch.chat.sdk.SinchIdentity
import com.sinch.chat.sdk.SinchMetadata
import com.sinch.chat.sdk.SinchMetadataMode
import com.sinch.chat.sdk.SinchRegion
import com.sinch.chat.sdk.SinchStartChatOptions
import com.sinch.chat.sdk.extensions.HmacSha512

// Sinch Dashboard Credentials.
val PROJECT_ID = "{{ PROJECT_ID }}"
val CLIENT_ID = "{{ CLIENT_ID }}"
val CONFIG_ID = "{{ CONFIG_ID }}"

val SECRET = "{{ SECRET }}"

// Company Backend
val ORDER_ID_FROM_BACKEND = "order_1"

val exampleCustomerID = "customer_1"
val exampleDriverID = "driver_1"


class MainActivity : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SinchChatSDK.initialize(this.baseContext, null)
        enableEdgeToEdge()
        setContent {
            DeliveryAppDemoTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var isLoading = false

    fun start(asDriver: Boolean) {
        val config = SinchConfig(
            CLIENT_ID,
            PROJECT_ID,
            CONFIG_ID,
            SinchRegion.EU1,
            "",
        )
        var userID = exampleCustomerID
        var toWhoIWantToCallAndSendMessageID = exampleDriverID
        if (asDriver) {
            userID = exampleDriverID
            toWhoIWantToCallAndSendMessageID = exampleCustomerID
        }

        val signedUUID = HmacSha512.generate(userID, SECRET)
        val identity = SinchIdentity.SelfSigned(userID, signedUUID)

        SinchChatSDK.setIdentity(config, identity) {
            if (it.isSuccess) {
                SinchChatSDK.chat.start(context, getOptions(ORDER_ID_FROM_BACKEND, toWhoIWantToCallAndSendMessageID))
            }
        }
    }

    val driverText = "Start Driver"
    val customerText = "Start Customer"


    Column {
        Text(
            text = "Hello $name!",
            modifier = modifier
        )
        Button(onClick = {
            start(true)
        }) {
            if (isLoading) {
                Text(
                    text = "Loading...",
                )
            } else {
                Text(
                    text = driverText,
                )
            }
        }
        Button(onClick = {
            start(false)
        }) {
            if (isLoading) {
                Text(
                    text = "Loading...",
                )
            } else {
                Text(
                    text = customerText,
                )
            }
        }
    }
}

fun getOptions(orderID: String, toWhoIWantToCallAndSendMessageID: String): SinchStartChatOptions {
    val metadata = mutableListOf<SinchMetadata>()

    metadata.add(SinchMetadata.Custom("addressee", toWhoIWantToCallAndSendMessageID, SinchMetadataMode.EachMessage))
    metadata.add(SinchMetadata.Custom("senderDisplayName", "", SinchMetadataMode.EachMessage))
    metadata.add(SinchMetadata.Custom("senderPictureUrl", "", SinchMetadataMode.EachMessage))

    return SinchStartChatOptions(
        topicID = orderID,
        metadata = metadata.toList()
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    DeliveryAppDemoTheme {
        Greeting("Android")
    }
}